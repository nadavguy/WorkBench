/*
 * BluetoothImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_BLUETOOTHIMAGES_H_
#define SCREEN_IMAGE_BLUETOOTHIMAGES_H_

extern const unsigned char gImage_Bluetooth_Disconnected[];
extern const unsigned char gImage_Bluetooth_Searching[];
extern const unsigned char gImage_Bluetooth_Connected[];



#endif /* SCREEN_IMAGE_BLUETOOTHIMAGES_H_ */
