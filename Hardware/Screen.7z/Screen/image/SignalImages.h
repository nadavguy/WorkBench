/*
 * SignalImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_SIGNALIMAGES_H_
#define SCREEN_IMAGE_SIGNALIMAGES_H_

extern const unsigned char gImage_Signal_RedNone[];
extern const unsigned char gImage_Signal_Low[];
extern const unsigned char gImage_Signal_Medium[];
extern const unsigned char gImage_Signal_Strong[];


#endif /* SCREEN_IMAGE_SIGNALIMAGES_H_ */
