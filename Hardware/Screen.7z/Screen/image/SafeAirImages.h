/*
 * SafeAirImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_SAFEAIRIMAGES_H_
#define SCREEN_IMAGE_SAFEAIRIMAGES_H_

extern const unsigned char gImage_SafeAir_Auto_Trigger[];
extern const unsigned char gImage_SafeAir_Manual_Trigger[];

#endif /* SCREEN_IMAGE_SAFEAIRIMAGES_H_ */
