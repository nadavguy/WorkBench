/*
 * AutoPilotImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_AUTOPILOTIMAGES_H_
#define SCREEN_IMAGE_AUTOPILOTIMAGES_H_

extern const unsigned char gImage_AutoPilot_Disconnected[];
extern const unsigned char gImage_AutoPilot_Connected[];


#endif /* SCREEN_IMAGE_AUTOPILOTIMAGES_H_ */
