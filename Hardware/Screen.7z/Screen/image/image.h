#ifndef _IMAGE_H_
#define _IMAGE_H_

extern const unsigned char gImage_1[];
extern const unsigned char gImage_70X70[];

extern const unsigned char gImage_WarningRed_Icon_24[];
extern const unsigned char gImage_Parachute_24[];
extern const unsigned char gImage_Altitude_24[];

#endif
