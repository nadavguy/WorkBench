/*
 * LogoImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_LOGOIMAGES_H_
#define SCREEN_IMAGE_LOGOIMAGES_H_

extern const unsigned char gImage_Logo[];
extern const unsigned char gImage_Logo_36[];
extern const unsigned char gImage_SafeAir_Logo_74_11[];
extern const unsigned char gImage_SafeAir_Logo_59_9[];
extern const unsigned char gImage_ParaZero_Logo_100_121_LSB[];



#endif /* SCREEN_IMAGE_LOGOIMAGES_H_ */
