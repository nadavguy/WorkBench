/*
 * LocationImages.h
 *
 *  Created on: Apr 6, 2021
 *      Author: gilad
 */

#ifndef SCREEN_IMAGE_LOCATIONIMAGES_H_
#define SCREEN_IMAGE_LOCATIONIMAGES_H_


extern const unsigned char gImage_Location_On[];
extern const unsigned char gImage_Location_Off[];


#endif /* SCREEN_IMAGE_LOCATIONIMAGES_H_ */
